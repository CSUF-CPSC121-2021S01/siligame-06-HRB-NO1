# Milestone 2

## Description
I learn how to use pointer to make code looks more complex.

## Challenges encountered
The logic of earies the end value and has_lost_ is pretty tricky.

## Things I've learned

To use pointer to make code more efficiency(maybe).
